package com.foodOnline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFoodOnlineAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
