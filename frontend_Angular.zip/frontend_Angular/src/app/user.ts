export class User {

    id:number;
    fname:string;
    lname:string;
	mailId:string;
	uname:string;
	pwd:string;
}
