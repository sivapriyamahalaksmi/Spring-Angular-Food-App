export class FoodOnline {

   id:number;
	name:string;
	price:number;
	qty:number;
	category:string;
	image:string;
	
}
