import { FoodOnline } from './food-online';

describe('FoodOnline', () => {
  it('should create an instance', () => {
    expect(new FoodOnline()).toBeTruthy();
  });
});
